﻿<#
 MariaDB/MySQL Windows Security Check Script
 KISA DBMS D-01~D-24 style audit / Windows PowerShell version v1.10
 - Converted from mariaDB_linux_audit.sh logic
 - Supports MariaDB/MySQL installed on Windows or remote MariaDB/MySQL connection
 - Finds mariadb.exe/mysql.exe automatically
 - Uses temporary defaults-extra-file to avoid exposing password in process arguments
 - Writes result even when client/connection fails
 - v1.10: fixes MariaDB 10.11 collation error by replacing privilege IN checks with explicit OR comparisons; keeps v1.9 SQL RAW/hash evidence

 PowerShell 5.1+ compatible.
#>

[CmdletBinding()]
param(
    [string]$Client = $env:MYSQL_CLIENT,
    [string]$HostName = $(if ($env:DB_HOST) { $env:DB_HOST } elseif ($env:MYSQL_HOST) { $env:MYSQL_HOST } else { 'localhost' }),
    [int]$Port = $(if ($env:DB_PORT) { [int]$env:DB_PORT } elseif ($env:MYSQL_PORT) { [int]$env:MYSQL_PORT } else { 3306 }),
    [string]$Socket = $(if ($env:DB_SOCKET) { $env:DB_SOCKET } elseif ($env:MYSQL_SOCKET) { $env:MYSQL_SOCKET } else { '' }),
    [string]$User = $(if ($env:DB_USER) { $env:DB_USER } elseif ($env:MYSQL_USER) { $env:MYSQL_USER } else { 'root' }),
    [string]$Password = $(if ($env:DB_PASS) { $env:DB_PASS } elseif ($env:MYSQL_PWD) { $env:MYSQL_PWD } elseif ($env:MARIADB_ROOT_PASSWORD) { $env:MARIADB_ROOT_PASSWORD } elseif ($env:MYSQL_ROOT_PASSWORD) { $env:MYSQL_ROOT_PASSWORD } else { '' }),
    [switch]$NoPrompt,
    [int]$ConnectTimeout = $(if ($env:DB_CONNECT_TIMEOUT) { [int]$env:DB_CONNECT_TIMEOUT } else { 5 }),
    [int]$QueryTimeout = $(if ($env:DB_QUERY_TIMEOUT) { [int]$env:DB_QUERY_TIMEOUT } else { 20 }),
    [string]$OutDir = (Get-Location).Path
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Continue'

$HostShort = $env:COMPUTERNAME
if ([string]::IsNullOrWhiteSpace($HostShort)) { $HostShort = 'unknown' }
$FileHead = "${HostShort}_mysql"
$Result = Join-Path $OutDir "$FileHead.txt"
$RawLog = Join-Path $OutDir "${FileHead}_RAW.txt"
$TempDefaults = $null

Remove-Item -LiteralPath $Result,$RawLog -Force -ErrorAction SilentlyContinue
$script:SqlRawSections = New-Object System.Collections.Generic.List[string]

function Write-Log {
    param([string]$Text = '')
    Add-Content -LiteralPath $Result -Value $Text -Encoding UTF8
}

function Write-ProgressLine {
    param([string]$Text)
    Write-Host "[PROGRESS] $Text"
}

function Mask-SensitiveText {
    param([string]$Text)
    if ($null -eq $Text) { return '' }
    $t = $Text -replace '(?i)(PASS|PASSWORD|PWD|TOKEN|SECRET|KEY|COOKIE|CREDENTIAL|AUTH)([^=]*=).*','$1$2***MASKED***'
    $t = $t -replace '(?i)(--password=)[^\s]+','$1***MASKED***'
    $t = $t -replace '(?i)(-p)[^\s]+','$1***MASKED***'
    return $t
}

function Section-Header {
    param([string]$Title,[string]$Basis)
    Write-Log "■ $Title"
    Write-Log "■ 기준 : $Basis"
    Write-Log "■ 현황"
}

function Write-Usage {
@'
Usage:
  powershell.exe -ExecutionPolicy Bypass -File .\mariaDB_windows_audit.ps1 [options]

Options:
  -Client PATH       mariadb.exe/mysql.exe path
  -HostName HOST     DB host, default localhost
  -Port PORT         DB port, default 3306
  -User USER         DB admin/audit user, default root
  -Password PASS     DB password. Prefer env DB_PASS/MYSQL_PWD to avoid history exposure.
  -NoPrompt          Do not ask interactively. Use env/options/defaults only.
  -ConnectTimeout N  DB connect timeout seconds, default 5
  -QueryTimeout N    Per SQL command timeout seconds, default 20
  -OutDir PATH       Output directory, default current directory

Environment variables:
  MYSQL_CLIENT, DB_HOST/MYSQL_HOST, DB_PORT/MYSQL_PORT,
  DB_USER/MYSQL_USER, DB_PASS/MYSQL_PWD/MARIADB_ROOT_PASSWORD/MYSQL_ROOT_PASSWORD

Examples:
  .\mariaDB_windows_audit.ps1
  .\mariaDB_windows_audit.ps1 -HostName 127.0.0.1 -User root -Password 'pass'
  $env:DB_PASS='pass'; .\mariaDB_windows_audit.ps1 -NoPrompt
'@ | Write-Host
}

function Test-Win32Executable {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { return $false }
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    if ([IO.Path]::GetExtension($Path).ToLowerInvariant() -ne '.exe') { return $false }
    try {
        $fs = [System.IO.File]::Open($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        try {
            if ($fs.Length -lt 2) { return $false }
            $buf = New-Object byte[] 2
            [void]$fs.Read($buf,0,2)
            return ($buf[0] -eq 0x4D -and $buf[1] -eq 0x5A)  # MZ header
        } finally { $fs.Close() }
    } catch {
        return $false
    }
}

function Resolve-DbClientPath {
    param([string]$Candidate)
    if ([string]::IsNullOrWhiteSpace($Candidate)) { return '' }

    $candidatePath = $Candidate.Trim('"')

    if (Test-Path -LiteralPath $candidatePath -PathType Leaf) {
        $resolved = (Resolve-Path -LiteralPath $candidatePath -ErrorAction SilentlyContinue).Path
        if (Test-Win32Executable -Path $resolved) { return $resolved }
        return ''
    }

    if (Test-Path -LiteralPath $candidatePath -PathType Container) {
        foreach ($leaf in @('mariadb.exe','mysql.exe')) {
            $joined = Join-Path $candidatePath $leaf
            if (Test-Win32Executable -Path $joined) { return (Resolve-Path -LiteralPath $joined).Path }
        }
        foreach ($sub in @('bin\mariadb.exe','bin\mysql.exe','client\bin\mariadb.exe','client\bin\mysql.exe')) {
            $joined = Join-Path $candidatePath $sub
            if (Test-Win32Executable -Path $joined) { return (Resolve-Path -LiteralPath $joined).Path }
        }
        return ''
    }

    $cmd = Get-Command $candidatePath -CommandType Application -ErrorAction SilentlyContinue | Where-Object { $_.Source -match '\.(exe)$' } | Select-Object -First 1
    if ($cmd -and (Test-Win32Executable -Path $cmd.Source)) { return $cmd.Source }
    return ''
}

function Find-DbClient {
    param([string]$Hint)

    $fromHint = Resolve-DbClientPath -Candidate $Hint
    if ($fromHint) { return $fromHint }

    foreach ($name in @('mariadb.exe','mysql.exe')) {
        $cmd = Get-Command $name -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($cmd -and (Test-Win32Executable -Path $cmd.Source)) { return $cmd.Source }
    }

    $roots = @(
        $env:ProgramFiles,
        ${env:ProgramFiles(x86)},
        $env:ProgramData,
        'C:\MariaDB',
        'C:\MySQL',
        'C:\xampp',
        'C:\laragon',
        'C:\Bitnami',
        'C:\tools'
    ) | Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique

    foreach ($r in $roots) {
        try {
            $found = Get-ChildItem -LiteralPath $r -Recurse -File -Filter '*.exe' -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -in @('mariadb.exe','mysql.exe') -and (Test-Win32Executable -Path $_.FullName) } |
                Sort-Object FullName |
                Select-Object -First 1
            if ($found) { return $found.FullName }
        } catch { }
    }
    return ''
}

function Convert-ToMysqlOptionValue {
    param([string]$Value)
    if ($null -eq $Value) { return '' }
    $v = $Value -replace '\\','\\\\'
    $v = $v -replace '"','\"'
    return '"' + $v + '"'
}

function Build-DefaultsFile {
    if ($script:TempDefaults -and (Test-Path -LiteralPath $script:TempDefaults)) {
        Remove-Item -LiteralPath $script:TempDefaults -Force -ErrorAction SilentlyContinue
    }
    $script:TempDefaults = Join-Path $env:TEMP ("mariadb_audit_client_{0}.cnf" -f ([guid]::NewGuid().ToString('N')))
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add('[client]')
    $lines.Add("user=$(Convert-ToMysqlOptionValue $User)")
    if ($Password.Length -gt 0) { $lines.Add("password=$(Convert-ToMysqlOptionValue $Password)") }
    if (-not [string]::IsNullOrWhiteSpace($Socket)) {
        $lines.Add("socket=$(Convert-ToMysqlOptionValue $Socket)")
    } else {
        # Windows mysql/mariadb client can behave differently for localhost/named-pipe/shared-memory.
        # Force TCP for audit consistency. localhost is normalized to 127.0.0.1 at connection-test fallback if needed.
        $lines.Add('protocol=tcp')
        $lines.Add("host=$(Convert-ToMysqlOptionValue $HostName)")
        $lines.Add("port=$Port")
    }
    $lines.Add("connect-timeout=$ConnectTimeout")
    Set-Content -LiteralPath $script:TempDefaults -Value $lines -Encoding ASCII
}

function Get-RawLogExcerpt {
    param([int]$MaxLines = 80)
    if (-not (Test-Path -LiteralPath $RawLog)) { return 'RAW log not found' }
    try {
        $txt = Get-Content -LiteralPath $RawLog -ErrorAction SilentlyContinue | Select-Object -Last $MaxLines | Out-String
        if ([string]::IsNullOrWhiteSpace($txt)) { return 'RAW log is empty' }
        return (Mask-SensitiveText $txt)
    } catch { return "RAW log read failed: $($_.Exception.Message)" }
}


function Join-WindowsArguments {
    param([string[]]$Items)
    $parts = New-Object System.Collections.Generic.List[string]
    foreach ($item in $Items) {
        if ($null -eq $item) { continue }
        $s = "$item"
        if ($s.Length -eq 0) { continue }
        if ($s -match '[\s"]') {
            $s = '"' + ($s -replace '\\(?=")','\\' -replace '"','\"') + '"'
        }
        [void]$parts.Add($s)
    }
    return ($parts -join ' ')
}
function Invoke-Client {
    param([string[]]$ClientArgs)
    $stdout = Join-Path $env:TEMP ("mariadb_audit_out_{0}.tmp" -f ([guid]::NewGuid().ToString('N')))
    $stderr = Join-Path $env:TEMP ("mariadb_audit_err_{0}.tmp" -f ([guid]::NewGuid().ToString('N')))

    if ($null -eq $ClientArgs) { $ClientArgs = @() }
    $cleanClientArgs = @()
    foreach ($a in $ClientArgs) {
        if ($null -ne $a -and ("$a").Length -gt 0) { $cleanClientArgs += "$a" }
    }

    $allArgs = @("--defaults-extra-file=$script:TempDefaults") + $cleanClientArgs
    $maskedArgs = (($allArgs -join " ") -replace [regex]::Escape($script:TempDefaults), "<defaults-extra-file>")
    Add-Content -LiteralPath $RawLog -Value ("CLIENT_EXEC: {0} {1}" -f $script:Client, $maskedArgs) -Encoding UTF8
    Add-Content -LiteralPath $RawLog -Value ("CLIENT_ARG_COUNT: {0}" -f $allArgs.Count) -Encoding UTF8

    try {
        if (-not (Test-Win32Executable -Path $script:Client)) {
            $msg = "Invalid Win32 client executable: $script:Client"
            Add-Content -LiteralPath $RawLog -Value $msg -Encoding UTF8
            return [pscustomobject]@{ ExitCode = 193; StdOut = ''; StdErr = $msg }
        }

        # Use direct ProcessStartInfo + quoted Arguments string for Windows PowerShell 5.1 compatibility.
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $script:Client
        $psi.Arguments = Join-WindowsArguments -Items $allArgs
        Add-Content -LiteralPath $RawLog -Value ("CLIENT_ARGUMENT_STRING: {0}" -f (($psi.Arguments) -replace [regex]::Escape($script:TempDefaults), "<defaults-extra-file>")) -Encoding UTF8
        $psi.UseShellExecute = $false
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        $psi.CreateNoWindow = $true
        $psi.WorkingDirectory = (Split-Path -Parent $script:Client)

        $proc = New-Object System.Diagnostics.Process
        $proc.StartInfo = $psi
        [void]$proc.Start()
    } catch {
        $msg = "Process start failed for client [$script:Client]: $($_.Exception.Message)"
        Add-Content -LiteralPath $RawLog -Value $msg -Encoding UTF8
        return [pscustomobject]@{ ExitCode = 193; StdOut = ''; StdErr = $msg }
    }

    if (-not $proc.WaitForExit($QueryTimeout * 1000)) {
        try { $proc.Kill() } catch { }
        $out = try { $proc.StandardOutput.ReadToEnd() } catch { '' }
        $err = try { $proc.StandardError.ReadToEnd() } catch { '' }
        Add-Content -LiteralPath $RawLog -Value "TIMEOUT after ${QueryTimeout}s: $($cleanClientArgs -join ' ')" -Encoding UTF8
        if ($err) { Add-Content -LiteralPath $RawLog -Value (Mask-SensitiveText $err) -Encoding UTF8 }
        return [pscustomobject]@{ ExitCode = 124; StdOut = $out; StdErr = $err }
    }

    $outText = try { $proc.StandardOutput.ReadToEnd() } catch { '' }
    $errText = try { $proc.StandardError.ReadToEnd() } catch { '' }
    if ($errText) { Add-Content -LiteralPath $RawLog -Value (Mask-SensitiveText $errText) -Encoding UTF8 }
    return [pscustomobject]@{ ExitCode = $proc.ExitCode; StdOut = $outText; StdErr = $errText }
}

function Invoke-Query {
    param([string]$Sql,[switch]$SkipColumnNames,[switch]$Raw)
    $clientArgs = @('--batch')
    if ($Raw) { $clientArgs += '--raw' }
    if ($SkipColumnNames) { $clientArgs += '--skip-column-names' }
    $clientArgs += @('-e', $Sql)
    return Invoke-Client -ClientArgs $clientArgs
}

function Invoke-QueryText {
    param([string]$Sql)
    $r = Invoke-Query -Sql $Sql -SkipColumnNames -Raw
    if ($r.StdOut) { return $r.StdOut.Trim() }
    return ''
}

function Add-SqlRawSection {
    param([string]$Label,[string]$Sql,[object]$QueryResult)
    if ([string]::IsNullOrWhiteSpace($Label)) { $Label = 'UNLABELED QUERY' }
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine(('### {0}' -f $Label))
    [void]$sb.AppendLine('[SQL]')
    [void]$sb.AppendLine($Sql.Trim())
    [void]$sb.AppendLine('[EXIT_CODE]')
    [void]$sb.AppendLine([string]$QueryResult.ExitCode)
    [void]$sb.AppendLine('[STDOUT]')
    if ($QueryResult.StdOut) { [void]$sb.AppendLine($QueryResult.StdOut.TrimEnd()) } else { [void]$sb.AppendLine('(empty)') }
    if ($QueryResult.StdErr) {
        [void]$sb.AppendLine('[STDERR]')
        [void]$sb.AppendLine((Mask-SensitiveText $QueryResult.StdErr).TrimEnd())
    }
    [void]$script:SqlRawSections.Add($sb.ToString())
}

function Add-QueryToResult {
    param([string]$Sql,[switch]$SkipColumnNames,[switch]$Raw,[string]$Label = '')
    $r = Invoke-Query -Sql $Sql -SkipColumnNames:$SkipColumnNames -Raw:$Raw
    if ($r.StdOut) { Add-Content -LiteralPath $Result -Value $r.StdOut.TrimEnd() -Encoding UTF8 }
    $rawLabel = $Label
    if ([string]::IsNullOrWhiteSpace($rawLabel)) {
        $rawLabel = $Sql.Trim()
        if ($rawLabel.Length -gt 90) { $rawLabel = $rawLabel.Substring(0,90) + '...' }
    }
    Add-SqlRawSection -Label $rawLabel -Sql $Sql -QueryResult $r
    if ($r.ExitCode -ne 0) {
        Add-Content -LiteralPath $RawLog -Value "QUERY_EXIT_CODE=$($r.ExitCode) SQL=$($Sql.Substring(0,[Math]::Min(300,$Sql.Length)))" -Encoding UTF8
    }
}

function Write-SqlRawDataToResult {
    Write-Log ''
    Write-Log '==================== SQL QUERY RAW DATA ===================='
    if ($script:SqlRawSections.Count -eq 0) {
        Write-Log 'No SQL query raw data collected.'
        return
    }
    foreach ($section in $script:SqlRawSections) {
        Add-Content -LiteralPath $Result -Value $section.TrimEnd() -Encoding UTF8
        Write-Log ''
    }
}

function Compare-VersionText {
    param([string]$Left,[string]$Right)
    try {
        $lv = [version](($Left -replace '[^0-9\.]','').Trim('.'))
        $rv = [version](($Right -replace '[^0-9\.]','').Trim('.'))
        return $lv.CompareTo($rv)
    } catch {
        return $null
    }
}

function Get-DbFlavorText {
    param([string]$VersionText)
    if ($VersionText -match '(?i)mariadb') { return 'MariaDB' }
    try {
        $vc = Invoke-QueryText "SELECT @@version_comment;"
        if ($vc -match '(?i)mariadb') { return 'MariaDB' }
    } catch { }
    return 'MySQL'
}

function Test-TcpAnyListening3306 {
    try {
        $lines = @(netstat -ano | Select-String -Pattern ':3306\s' | ForEach-Object { $_.Line })
        foreach ($l in $lines) {
            if ($l -match 'LISTENING' -and ($l -match '0\.0\.0\.0:3306' -or $l -match '\[::\]:3306')) { return $true }
        }
    } catch { }
    return $false
}

function Test-FirewallAllow3306 {
    try {
        $rules = Get-NetFirewallRule -ErrorAction Stop | Where-Object { $_.Enabled -eq 'True' -and $_.Direction -eq 'Inbound' -and $_.Action -eq 'Allow' }
        foreach ($r in $rules) {
            if ($r.DisplayName -match '3306|maria|mysql' -or $r.Name -match '3306|maria|mysql') { return $true }
            try {
                $pf = Get-NetFirewallPortFilter -AssociatedNetFirewallRule $r -ErrorAction SilentlyContinue
                if ($pf -and ($pf.LocalPort -contains '3306' -or $pf.LocalPort -eq 'Any')) { return $true }
            } catch { }
        }
    } catch { }
    return $false
}

function Collect-WindowsRaw {
    Write-Log ''
    Write-Log '------------------------Windows / MariaDB RAW---------------------------'
    Write-Log '[OS]'
    try { Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber,OSArchitecture,LastBootUpTime | Format-List | Out-String | Add-Content -LiteralPath $Result -Encoding UTF8 } catch { Write-Log "OS query failed: $_" }
    Write-Log '[Computer System]'
    try { Get-CimInstance Win32_ComputerSystem | Select-Object Manufacturer,Model,Domain,UserName | Format-List | Out-String | Add-Content -LiteralPath $Result -Encoding UTF8 } catch { }
    Write-Log '[MariaDB/MySQL Services]'
    try {
        Get-CimInstance Win32_Service | Where-Object { $_.Name -match 'maria|mysql' -or $_.DisplayName -match 'maria|mysql' -or $_.PathName -match 'maria|mysql' } |
            Select-Object Name,DisplayName,State,StartMode,StartName,PathName | Format-List | Out-String | Add-Content -LiteralPath $Result -Encoding UTF8
    } catch { Write-Log "Service query failed: $_" }
    Write-Log '[MariaDB/MySQL Processes]'
    try {
        Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'maria|mysql|mysqld' -or $_.CommandLine -match 'maria|mysql|mysqld' } |
            Select-Object ProcessId,Name,ExecutablePath,CommandLine | Format-List | Out-String | ForEach-Object { Mask-SensitiveText $_ } | Add-Content -LiteralPath $Result -Encoding UTF8
    } catch { Write-Log "Process query failed: $_" }
    Write-Log '[Listening Ports - netstat filtered]'
    try { (netstat -ano | Select-String -Pattern ':3306|mysql|maria' | Out-String) | Add-Content -LiteralPath $Result -Encoding UTF8 } catch { Write-Log "netstat failed: $_" }
    Write-Log '[Firewall Rules filtered]'
    try {
        Get-NetFirewallRule -ErrorAction Stop | Where-Object { $_.DisplayName -match 'maria|mysql|3306' -or $_.Name -match 'maria|mysql|3306' } |
            Select-Object DisplayName,Enabled,Direction,Action,Profile | Format-Table -AutoSize | Out-String | Add-Content -LiteralPath $Result -Encoding UTF8
    } catch { Write-Log 'Get-NetFirewallRule unavailable or access denied' }
    Write-Log '[Environment - masked]'
    Get-ChildItem Env: | Sort-Object Name | ForEach-Object { Mask-SensitiveText ("{0}={1}" -f $_.Name,$_.Value) } | Add-Content -LiteralPath $Result -Encoding UTF8
}

function Get-ServiceDefaultsFileCandidates {
    $paths = New-Object System.Collections.Generic.List[string]
    try {
        Get-CimInstance Win32_Service | Where-Object { $_.Name -match 'maria|mysql' -or $_.DisplayName -match 'maria|mysql' -or $_.PathName -match 'maria|mysql' } | ForEach-Object {
            $pn = [string]$_.PathName
            if ($pn -match '"--defaults-file=([^"]+)"') { $paths.Add($Matches[1]) }
            elseif ($pn -match '--defaults-file="([^"]+)"') { $paths.Add($Matches[1]) }
            elseif ($pn -match '--defaults-file=([^\s"]+)') { $paths.Add($Matches[1].Trim('"')) }
        }
    } catch { }
    try {
        Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'mysqld|mariadbd|mysql' -or $_.CommandLine -match 'mysqld|mariadbd|mysql' } | ForEach-Object {
            $pn = [string]$_.CommandLine
            if ($pn -match '"--defaults-file=([^"]+)"') { $paths.Add($Matches[1]) }
            elseif ($pn -match '--defaults-file="([^"]+)"') { $paths.Add($Matches[1]) }
            elseif ($pn -match '--defaults-file=([^\s"]+)') { $paths.Add($Matches[1].Trim('"')) }
        }
    } catch { }
    return ($paths | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Leaf) } | Select-Object -Unique)
}

function Test-ProbablyTextFile {
    param([string]$Path)
    try {
        $fi = Get-Item -LiteralPath $Path -ErrorAction Stop
        if ($fi.Length -gt 1048576) { return $false }
        $fs = [System.IO.File]::OpenRead($Path)
        try {
            $len = [Math]::Min(4096, [int]$fs.Length)
            if ($len -le 0) { return $true }
            $buf = New-Object byte[] $len
            [void]$fs.Read($buf,0,$len)
            return -not ($buf -contains 0)
        } finally { $fs.Close() }
    } catch { return $false }
}

function Get-MariaDbConfigCandidates {
    $list = New-Object System.Collections.Generic.List[object]
    $svcFiles = @(Get-ServiceDefaultsFileCandidates)
    foreach ($svcFile in $svcFiles) {
        if ($svcFile -and (Test-Path -LiteralPath $svcFile -PathType Leaf)) {
            try { $list.Add((Get-Item -LiteralPath $svcFile)) } catch { }
        }
    }

    # If a running MariaDB/MySQL service explicitly points to --defaults-file, prefer that active service configuration.
    # This avoids mixing stale MySQL/MariaDB configs from old installations.
    if ($list.Count -gt 0) {
        foreach ($sf in @($list | Select-Object -ExpandProperty FullName -Unique)) {
            try {
                $base = Split-Path -Parent $sf
                Get-ChildItem -LiteralPath $base -File -ErrorAction SilentlyContinue |
                    Where-Object { $_.Extension -in @('.ini','.cnf') -and (Test-ProbablyTextFile -Path $_.FullName) } |
                    ForEach-Object { $list.Add($_) }
            } catch { }
        }
        return ($list | Sort-Object FullName -Unique | Select-Object -First 30)
    }

    $roots = New-Object System.Collections.Generic.List[string]
    foreach ($r in @(
        (Split-Path -Parent $script:Client),
        (Join-Path (Split-Path -Parent $script:Client) '..'),
        (Join-Path (Split-Path -Parent $script:Client) '..\data'),
        (Join-Path $env:ProgramFiles 'MariaDB*'),
        (Join-Path $env:ProgramFiles 'MySQL*'),
        (Join-Path ${env:ProgramFiles(x86)} 'MariaDB*'),
        (Join-Path ${env:ProgramFiles(x86)} 'MySQL*'),
        (Join-Path $env:ProgramData 'MySQL*'),
        (Join-Path $env:ProgramData 'MariaDB*'),
        'C:\MariaDB*','C:\MySQL*','C:\xampp\mysql','C:\laragon\bin\mysql*','C:\Bitnami*'
    )) {
        if (-not [string]::IsNullOrWhiteSpace($r)) {
            try { Get-Item -Path $r -ErrorAction SilentlyContinue | Where-Object { $_.PSIsContainer } | ForEach-Object { $roots.Add($_.FullName) } } catch { }
        }
    }

    foreach ($r in ($roots | Select-Object -Unique)) {
        try {
            Get-ChildItem -LiteralPath $r -Recurse -File -ErrorAction SilentlyContinue |
                Where-Object {
                    ($_.Extension -in @('.ini','.cnf')) -and
                    ($_.Name -match '^(my|mysql|maria|server|client|mysqld).*\.(ini|cnf)$' -or $_.FullName -match 'maria|mysql|mysqld')
                } |
                ForEach-Object { $list.Add($_) }
        } catch { }
    }

    return ($list | Sort-Object FullName -Unique | Select-Object -First 80)
}

function Write-OneConfigFileRaw {
    param([object]$FileItem)
    $f = $FileItem
    Write-Log "[FILE] $($f.FullName)"
    try {
        $acl = Get-Acl -LiteralPath $f.FullName
        Write-Log ("Owner: {0}" -f $acl.Owner)
        Write-Log ("Length: {0}, LastWriteTime: {1}" -f $f.Length,$f.LastWriteTime)
        Write-Log '[ACL]'
        ($acl.Access | Select-Object IdentityReference,FileSystemRights,AccessControlType,IsInherited | Format-Table -AutoSize | Out-String) | Add-Content -LiteralPath $Result -Encoding UTF8
    } catch { Write-Log "ACL read failed: $_" }
    Write-Log '[Selected content - masked]'
    if (Test-ProbablyTextFile -Path $f.FullName) {
        try {
            Get-Content -LiteralPath $f.FullName -ErrorAction SilentlyContinue |
                Where-Object { $_ -match 'bind|port|socket|datadir|basedir|log|general|slow|secure_file_priv|local_infile|ssl|require_secure_transport|plugin|server_audit|password|user|default_authentication_plugin' } |
                Select-Object -First 160 |
                ForEach-Object { Mask-SensitiveText $_ } | Add-Content -LiteralPath $Result -Encoding UTF8
        } catch { Write-Log "content read failed: $_" }
    } else {
        Write-Log 'Skipped content dump: file is binary-like or larger than 1MB'
    }
    Write-Log ''
}

function Collect-ConfigFilesRaw {
    Write-Log ''
    Write-Log '------------------------Config File RAW---------------------------'

    $activePaths = @(Get-ServiceDefaultsFileCandidates)
    $activeFiles = @()
    foreach ($ap in $activePaths) {
        if ($ap -and (Test-Path -LiteralPath $ap -PathType Leaf)) {
            try { $activeFiles += (Get-Item -LiteralPath $ap) } catch { }
        }
    }

    if ($activeFiles.Count -gt 0) {
        Write-Log '[ACTIVE CONFIG FILE - service/process --defaults-file]'
        foreach ($f in ($activeFiles | Sort-Object FullName -Unique)) { Write-OneConfigFileRaw -FileItem $f }
    } else {
        Write-Log '[ACTIVE CONFIG FILE]'
        Write-Log 'Active --defaults-file not detected from Windows service/process command line.'
        Write-Log ''
    }

    $allFiles = @(Get-MariaDbConfigCandidates)
    $activeFullNames = @($activeFiles | ForEach-Object { $_.FullName.ToLowerInvariant() })
    $otherFiles = @($allFiles | Where-Object { $activeFullNames -notcontains $_.FullName.ToLowerInvariant() })

    if ($otherFiles.Count -gt 0) {
        Write-Log '[OTHER MYSQL/MARIADB CONFIG CANDIDATES - reference only]'
        foreach ($f in ($otherFiles | Sort-Object FullName -Unique | Select-Object -First 30)) { Write-OneConfigFileRaw -FileItem $f }
    } elseif ($activeFiles.Count -eq 0) {
        Write-Log 'Config file candidates not found'
    }
}

function Write-ItemsWhenSqlUnavailable {
    param([string]$ReasonCode,[string]$ReasonMessage)

    Write-Log ''
    Write-Log '==================== CHECK ITEMS / SQL NOT EXECUTED ===================='
    Write-Log "SQL 기반 항목은 DB 접속 실패/클라이언트 오류로 자동조회하지 못했습니다."
    Write-Log "ReasonCode : $ReasonCode"
    Write-Log "Reason     : $ReasonMessage"
    Write-Log "Note       : Windows 서비스/프로세스/포트/설정파일 RAW는 하단에 수집됩니다."
    Write-Log ''

    $items = @(
        @('D-01','기본 계정의 패스워드, 정책 등을 변경하여 사용','ERROR','DB 접속 실패로 mysql.user 조회 불가'),
        @('D-02','scott 등 Demonstration 및 불필요 계정을 제거하거나 잠금 설정 후 사용','ERROR','DB 접속 실패로 계정 목록 조회 불가'),
        @('D-03','패스워드의 사용기간 및 복잡도 기관 정책에 맞도록 설정','ERROR','DB 접속 실패로 패스워드 정책 조회 불가'),
        @('D-04','데이터베이스 관리자 권한을 꼭 필요한 계정 및 그룹에 허용','ERROR','DB 접속 실패로 관리자 권한 조회 불가'),
        @('D-05','패스워드 재사용에 대한 제약','N/A','MariaDB/MySQL 버전/플러그인별 수동 확인 필요'),
        @('D-06','DB 사용자 계정 개별적 부여','ERROR','DB 접속 실패로 DB 권한 조회 불가'),
        @('D-07','원격에서 DB 서버로의 접속 제한','WARN','DB 계정 Host 조회 불가. 하단 포트/방화벽 RAW 참고'),
        @('D-08','DBA이외의 인가되지 않은 사용자 시스템 테이블 접근 제한 설정','ERROR','DB 접속 실패로 mysql 스키마 권한 조회 불가'),
        @('D-09','오라클 데이터베이스의 경우 리스너 패스워드 설정','N/A','Oracle 전용'),
        @('D-10','불필요한 ODBC/OLE-DB 데이터 소스와 드라이브 제거','WARN','Windows DSN은 별도 수동 확인 필요'),
        @('D-11','일정 횟수의 로그인 실패 시 잠금 정책 설정','WARN','MariaDB/MySQL 버전/플러그인별 수동 확인 필요'),
        @('D-12','DB 주요 파일 보호 등을 위해 DB 계정의 umask를 022 이상으로 설정','WARN','Windows는 umask 대신 서비스 계정/NTFS ACL 확인'),
        @('D-13','DB 주요 설정파일, 패스워드 파일 등 주요 파일 접근 권한 설정','WARN','하단 Config File RAW의 Owner/ACL 확인'),
        @('D-14','리스너 로그 및 trace 파일 변경 권한 제한','N/A','Oracle 전용'),
        @('D-15','응용프로그램 또는 DBA 계정의 Role이 Public으로 설정되지 않도록 조정','N/A','Oracle/MSSQL 중심 항목'),
        @('D-16','OS_ROLES, REMOTE_OS_AUTHENTICATION, REMOTE_OS_ROLES를 FALSE로 설정','N/A','Oracle 전용'),
        @('D-17','패스워드 확인함수가 설정되어 적용되는가?','N/A','Oracle 중심 항목'),
        @('D-18','인가되지 않은 Object Owner가 존재하지 않는가?','N/A','Oracle 중심 항목'),
        @('D-19','grant option이 role에 의해 부여되도록 설정','N/A','Oracle 중심 항목'),
        @('D-20','데이터베이스의 자원 제한 기능을 TRUE로 설정','N/A','Oracle 중심 항목'),
        @('D-21','최신 보안 패치와 벤더 권고사항 적용','ERROR','DB 버전 조회 실패. 클라이언트/서비스 RAW 기준 수동 확인'),
        @('D-22','접근, 변경, 삭제 등의 감사기록 정책 적합성','WARN','DB 접속 실패로 감사 변수 조회 불가'),
        @('D-23','보안에 취약하지 않은 버전의 데이터베이스 사용','ERROR','DB 버전 조회 실패'),
        @('D-24','Audit Table은 데이터베이스 관리자 계정에 속해 있도록 설정','N/A','Oracle 중심 항목')
    )

    foreach ($it in $items) {
        Write-Log '------------------------------------------------------------'
        Write-Log ("ITEM CODE   : {0}" -f $it[0])
        Write-Log ("CHECK ITEM  : {0}" -f $it[1])
        Write-Log ("RESULT CODE : {0}" -f $it[2])
        Write-Log ("CURRENT     : {0}" -f $it[3])
        Write-Log "BASIS       : $ReasonCode - $ReasonMessage"
        Write-Log 'ACTION      : DB 접속정보, 계정 권한, 서비스 상태, 방화벽, 클라이언트 경로 확인 후 재수행'
        Write-Log ''
    }
}

function Fail-ReportAndExit {
    param([string]$Code,[string]$Message)
    Write-Log ''
    Write-Log '[AUDIT STATUS]'
    Write-Log $Code
    Write-Log $Message
    Write-Log ''
    Write-Log '[DB CLIENT ERROR EXCERPT]'
    Write-Log (Get-RawLogExcerpt)
    Write-ItemsWhenSqlUnavailable -ReasonCode $Code -ReasonMessage $Message
    Collect-WindowsRaw
    Collect-ConfigFilesRaw
    Write-Host $Message
    Write-Host "Please Return your $Result"
    if ($script:TempDefaults -and (Test-Path $script:TempDefaults)) { Remove-Item -LiteralPath $script:TempDefaults -Force -ErrorAction SilentlyContinue }
    exit 0
}

function Write-InitialProfile {
    @(
        '============================================================',
        'KISA Windows MariaDB/MySQL Audit v1.10',
        '============================================================',
        '[SERVER PROFILE]',
        ('Hostname       : {0}' -f $env:COMPUTERNAME),
        ('FQDN           : {0}' -f ([System.Net.Dns]::GetHostByName(($env:computerName)).HostName)),
        ('IPv4/IPv6      : {0}' -f ((Get-NetIPAddress -AddressFamily IPv4,IPv6 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notmatch '^169\.254|^fe80' } | Select-Object -ExpandProperty IPAddress) -join ' ')),
        ('OS             : {0}' -f ((Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue).Caption)),
        ('Kernel/Build   : {0}' -f ((Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue).Version)),
        ('Exec User      : {0}\{1}' -f $env:USERDOMAIN,$env:USERNAME),
        ('IsAdmin        : {0}' -f ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)),
        ('Time           : {0}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')),
        ''
    ) | Set-Content -LiteralPath $Result -Encoding UTF8
}

try {
    Write-InitialProfile
    Write-ProgressLine 'detecting MariaDB/MySQL client'
    $script:Client = Find-DbClient -Hint $Client
    if (-not $script:Client) { Fail-ReportAndExit 'DB_CLIENT_NOT_FOUND' 'mariadb.exe/mysql.exe client not found. SQL 점검은 수행할 수 없습니다.' }

    if (-not $NoPrompt -and [Environment]::UserInteractive) {
        Write-Host '#####################################################################################################################'
        Write-Host '# 진단 진행을 위한 Connection 정보를 입력받습니다. Enter 입력 시 기본값/환경변수를 사용합니다.'
        Write-Host '#####################################################################################################################'
        $v = Read-Host "MariaDB/MySQL Client Path (default:$script:Client)"; if ($v) { $script:Client = $v }
        $resolvedPromptClient = Resolve-DbClientPath -Candidate $script:Client
        if (-not $resolvedPromptClient) { Fail-ReportAndExit 'DB_CLIENT_INVALID' "Invalid MariaDB/MySQL client path. 실제 mysql.exe 또는 mariadb.exe 파일 경로를 지정해야 합니다. Current=$script:Client" }
        $script:Client = $resolvedPromptClient
        $v = Read-Host "MySQL Host (default:$HostName)"; if ($v) { $HostName = $v }
        $v = Read-Host "MySQL Port (default:$Port)"; if ($v) { $Port = [int]$v }
        $v = Read-Host "MySQL Admin ID (default:$User)"; if ($v) { $User = $v }
        $sec = Read-Host 'MySQL Admin Password (empty allowed)' -AsSecureString
        $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
        try { $plain = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
        if ($plain.Length -gt 0) { $Password = $plain }
    } else {
        Write-ProgressLine 'non-interactive/default connection values are used'
    }

    if ($Port -lt 1 -or $Port -gt 65535) { Fail-ReportAndExit 'INVALID_PORT' "Invalid port: $Port" }

    $resolvedFinalClient = Resolve-DbClientPath -Candidate $script:Client
    if (-not $resolvedFinalClient) {
        Fail-ReportAndExit 'DB_CLIENT_INVALID' "Invalid MariaDB/MySQL client. 실제 Windows 실행파일 mysql.exe 또는 mariadb.exe가 아닙니다. Current=$script:Client"
    }
    $script:Client = $resolvedFinalClient

    Build-DefaultsFile

    Write-Log '[DB CONNECTION PROFILE]'
    Write-Log "Client : $script:Client"
    Write-Log "Host   : $HostName"
    Write-Log "Port   : $Port"
    Write-Log "Socket : $(if ($Socket) { $Socket } else { 'N/A' })"
    Write-Log "User   : $User"
    Write-Log ("PasswordProvided : {0}" -f ($(if ($Password.Length -gt 0) {'Y'} else {'N'})))
    Write-Log "ConnectTimeout : $ConnectTimeout"
    Write-Log "QueryTimeout   : $QueryTimeout"
    Write-Log ''

    Write-ProgressLine 'checking MariaDB/MySQL connection'
    $ConnectionAttemptNotes = New-Object System.Collections.Generic.List[string]
    $dbverResult = Invoke-Query -Sql "SELECT SUBSTRING_INDEX(VERSION(), '-', 1);" -SkipColumnNames -Raw
    $DBVER = if ($dbverResult.StdOut) { $dbverResult.StdOut.Trim() } else { '' }
    $ConnectionAttemptNotes.Add("attempt host=$HostName port=$Port exit=$($dbverResult.ExitCode) version=$DBVER")

    if (($dbverResult.ExitCode -ne 0 -or -not $DBVER) -and [string]::IsNullOrWhiteSpace($Socket) -and $HostName -ieq 'localhost') {
        Add-Content -LiteralPath $RawLog -Value 'Primary localhost connection failed. Retrying with host=127.0.0.1 and protocol=tcp.' -Encoding UTF8
        $HostName = '127.0.0.1'
        Build-DefaultsFile
        $dbverResult = Invoke-Query -Sql "SELECT SUBSTRING_INDEX(VERSION(), '-', 1);" -SkipColumnNames -Raw
        $DBVER = if ($dbverResult.StdOut) { $dbverResult.StdOut.Trim() } else { '' }
        $ConnectionAttemptNotes.Add("fallback host=127.0.0.1 port=$Port exit=$($dbverResult.ExitCode) version=$DBVER")
    }

    Write-Log '[DB CONNECTION ATTEMPTS]'
    foreach ($n in $ConnectionAttemptNotes) { Write-Log $n }
    Write-Log ''

    if ($dbverResult.ExitCode -ne 0 -or -not $DBVER) {
        Fail-ReportAndExit 'DB_CONNECTION_FAIL' "Connection failed. $RawLog 파일에 클라이언트 오류가 기록되었습니다. 본문 [DB CLIENT ERROR EXCERPT]를 확인하세요."
    }
    if ($DBVER -notmatch '^[0-9]+\.[0-9]+(\.[0-9]+)?') { Fail-ReportAndExit 'DB_VERSION_PARSE_FAIL' "Connection succeeded but DB version parsing failed: $DBVER" }

    $IS55MORE = Invoke-QueryText "SELECT VERSION() >= '5.5.0';"; if (-not $IS55MORE) { $IS55MORE = '0' }
    $IS57MORE = Invoke-QueryText "SELECT VERSION() >= '5.7.0';"; if (-not $IS57MORE) { $IS57MORE = '0' }

    $LAT_55='5.5.62'; $LAT_56='5.6.51'; $LAT_57='5.7.44'; $LAT_80='8.0.36'; $LAT_MARIA_104='10.4.34'
    [void](Invoke-Query -Sql "SET SESSION sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';")

    Section-Header 'D-01. 기본 계정의 패스워드, 정책 등을 변경하여 사용' '기본/업무 계정의 빈 패스워드 또는 ID와 동일한 패스워드가 없는 경우 양호'
    $SystemAccountFilter = "user NOT IN ('PUBLIC','mariadb.sys','mysql','mysql.sys','mysql.session')"
    if ($IS55MORE -eq '1') {
        if ($IS57MORE -eq '1') {
            $sql = @'
SELECT CONCAT('D-01', ',', IF(COUNT(T.user) > 0, 'X', 'O'), ',,') AS ''
FROM (
    SELECT user, plugin, authentication_string
    FROM mysql.user
    WHERE (__SYSTEM_ACCOUNT_FILTER__ OR user = '')
    GROUP BY user, plugin, authentication_string
) T
WHERE T.user = ''
   OR (
      T.plugin = 'mysql_native_password'
      AND (
          T.authentication_string = PASSWORD('')
          OR T.authentication_string = PASSWORD(T.user)
      )
   );
'@
            Add-QueryToResult -SkipColumnNames -Sql ($sql.Replace('__SYSTEM_ACCOUNT_FILTER__', $SystemAccountFilter))
            $sql = @'
SELECT CASE
WHEN (
    SELECT COUNT(*)
    FROM (
        SELECT user, plugin, authentication_string
        FROM mysql.user
        WHERE (__SYSTEM_ACCOUNT_FILTER__ OR user = '')
        GROUP BY user, plugin, authentication_string
    ) T
    WHERE T.user = ''
       OR (
          T.plugin = 'mysql_native_password'
          AND (
              T.authentication_string = PASSWORD('')
              OR T.authentication_string = PASSWORD(T.user)
          )
       )
) > 0
THEN '패스워드가 취약한(익명/미설정 또는 아이디와 동일) 계정이 존재함'
ELSE '패스워드가 취약한(익명/미설정 또는 아이디와 동일) 계정이 발견되지 않음'
END AS '';
'@
            Add-QueryToResult -SkipColumnNames -Sql ($sql.Replace('__SYSTEM_ACCOUNT_FILTER__', $SystemAccountFilter))
            $sql = @'
SELECT DISTINCT user, host, plugin,
       CASE
         WHEN user IN ('PUBLIC','mariadb.sys','mysql','mysql.sys','mysql.session') THEN 'SYSTEM_ACCOUNT_EXCLUDED'
         WHEN user = '' THEN 'ANONYMOUS_ACCOUNT'
         WHEN authentication_string = PASSWORD('') THEN 'EMPTY_PASSWORD'
         WHEN authentication_string = PASSWORD(user) THEN 'PASSWORD_SAME_AS_ID'
         WHEN authentication_string IS NULL OR authentication_string = '' THEN 'NO_AUTH_STRING_OR_PLUGIN_MANAGED'
         ELSE 'SET_OR_PLUGIN_MANAGED'
       END AS password_status
FROM mysql.user
ORDER BY user, host;
'@
            Add-QueryToResult -Sql $sql
        } else {
            $sql = @'
SELECT CONCAT('D-01', ',', IF(COUNT(T.user) > 0, 'X', 'O'), ',,') AS ''
FROM (
    SELECT user, password, plugin, authentication_string
    FROM mysql.user
    WHERE (__SYSTEM_ACCOUNT_FILTER__ OR user = '')
    GROUP BY user, password, plugin, authentication_string
) T
WHERE T.user = ''
   OR (T.plugin IS NULL AND T.password = PASSWORD(''))
   OR (T.plugin = 'mysql_native_password' AND (T.authentication_string = PASSWORD('') OR T.authentication_string = PASSWORD(T.user)));
'@
            Add-QueryToResult -SkipColumnNames -Sql ($sql.Replace('__SYSTEM_ACCOUNT_FILTER__', $SystemAccountFilter))
            $sql = @'
SELECT CASE
WHEN (
    SELECT COUNT(*)
    FROM (
        SELECT user, password, plugin, authentication_string
        FROM mysql.user
        WHERE (__SYSTEM_ACCOUNT_FILTER__ OR user = '')
        GROUP BY user, password, plugin, authentication_string
    ) T
    WHERE T.user = ''
       OR (T.plugin IS NULL AND T.password = PASSWORD(''))
       OR (T.plugin = 'mysql_native_password' AND (T.authentication_string = PASSWORD('') OR T.authentication_string = PASSWORD(T.user)))
) > 0
THEN '패스워드가 취약한(익명/미설정 또는 아이디와 동일) 계정이 존재함'
ELSE '패스워드가 취약한(익명/미설정 또는 아이디와 동일) 계정이 발견되지 않음'
END AS '';
'@
            Add-QueryToResult -SkipColumnNames -Sql ($sql.Replace('__SYSTEM_ACCOUNT_FILTER__', $SystemAccountFilter))
            $sql = @'
SELECT DISTINCT user, host, plugin,
       CASE
         WHEN user IN ('PUBLIC','mariadb.sys','mysql','mysql.sys','mysql.session') THEN 'SYSTEM_ACCOUNT_EXCLUDED'
         WHEN user = '' THEN 'ANONYMOUS_ACCOUNT'
         WHEN password = PASSWORD('') THEN 'EMPTY_PASSWORD'
         WHEN authentication_string = PASSWORD(user) THEN 'PASSWORD_SAME_AS_ID'
         ELSE 'SET_OR_PLUGIN_MANAGED'
       END AS password_status
FROM mysql.user
ORDER BY user, host;
'@
            Add-QueryToResult -Sql $sql
        }
    } else {
        $sql = @'
SELECT CONCAT('D-01', ',', IF(COUNT(T.user) > 0, 'X', 'O'), ',,') AS ''
FROM (SELECT user, password FROM mysql.user WHERE (__SYSTEM_ACCOUNT_FILTER__ OR user = '') GROUP BY user, password) T
WHERE T.user = '' OR T.password = PASSWORD('') OR T.password = PASSWORD(user);
'@
        Add-QueryToResult -SkipColumnNames -Sql ($sql.Replace('__SYSTEM_ACCOUNT_FILTER__', $SystemAccountFilter))
        $sql = @'
SELECT CASE
WHEN (SELECT COUNT(T.user) FROM (SELECT user, password FROM mysql.user WHERE (__SYSTEM_ACCOUNT_FILTER__ OR user = '') GROUP BY user, password) T WHERE T.user = '' OR T.password = PASSWORD('') OR T.password = PASSWORD(user)) > 0
THEN '패스워드가 취약한(익명/미설정 또는 아이디와 동일) 계정이 존재함'
ELSE '패스워드가 취약한(익명/미설정 또는 아이디와 동일) 계정이 발견되지 않음'
END AS '';
'@
        Add-QueryToResult -SkipColumnNames -Sql ($sql.Replace('__SYSTEM_ACCOUNT_FILTER__', $SystemAccountFilter))
        $sql = @'
SELECT DISTINCT user, host,
       CASE
         WHEN user IN ('PUBLIC','mariadb.sys','mysql','mysql.sys','mysql.session') THEN 'SYSTEM_ACCOUNT_EXCLUDED'
         WHEN user = '' THEN 'ANONYMOUS_ACCOUNT'
         WHEN password = PASSWORD('') THEN 'EMPTY_PASSWORD'
         WHEN password = PASSWORD(user) THEN 'PASSWORD_SAME_AS_ID'
         ELSE 'SET'
       END AS password_status
FROM mysql.user
ORDER BY user, host;
'@
        Add-QueryToResult -Sql $sql
    }
    Write-Log ''



    Write-Log ''
    Write-Log '[D-01 계정/인증 해시 RAW - audit evidence]'
    $d01HashSql = @'
SELECT User, Host, plugin, Password, authentication_string,
       CASE
         WHEN User IN ('PUBLIC','mariadb.sys','mysql','mysql.sys','mysql.session') THEN 'SYSTEM_ACCOUNT_EXCLUDED'
         WHEN User = '' THEN 'ANONYMOUS_ACCOUNT'
         WHEN Password = PASSWORD('') OR authentication_string = PASSWORD('') THEN 'EMPTY_PASSWORD'
         WHEN Password = PASSWORD(User) OR authentication_string = PASSWORD(User) THEN 'PASSWORD_SAME_AS_ID'
         WHEN (Password IS NULL OR Password = '') AND (authentication_string IS NULL OR authentication_string = '') THEN 'NO_PASSWORD_HASH_OR_PLUGIN_MANAGED'
         ELSE 'HASH_PRESENT_OR_PLUGIN_MANAGED'
       END AS password_status
FROM mysql.user
ORDER BY User, Host;
'@
    Add-QueryToResult -Sql $d01HashSql -Label 'D-01 account password/authentication hash raw'

    Section-Header 'D-02. scott 등 Demonstration 및 불필요 계정을 제거하거나 잠금 설정 후 사용' '계정 정보를 확인하여 불필요한 계정이 없는 경우 양호'
    Write-Log 'D-02,C,,'; Write-Log '[수동진단]사용하지 않는 계정에 대한 인터뷰 필요'; Write-Log ''; Write-Log '[설정]'
    Add-QueryToResult -Sql "SELECT u.user, d.db FROM mysql.user u LEFT JOIN mysql.db d ON u.user = d.user WHERE u.user <> '' GROUP BY u.user, d.db;"
    Write-Log ''

    Section-Header 'D-03. 패스워드의 사용기간 및 복잡도 기관 정책에 맞도록 설정' '패스워드를 주기적으로 변경하고, 패스워드 정책이 적용되어 있는 경우 양호'
    Write-Log 'D-03,C,,'; Write-Log '[수동진단]인터뷰 필요'; Write-Log ''

    $ADMIN_PRIV_COLS='Select_priv, Insert_priv, Update_priv, Delete_priv, Create_priv, Drop_priv, Reload_priv, Shutdown_priv, Process_priv, File_priv, Grant_priv, References_priv, Index_priv, Alter_priv, Show_db_priv, Super_priv, Create_tmp_table_priv, Lock_tables_priv, Execute_priv, Repl_slave_priv, Repl_client_priv, Create_view_priv, Show_view_priv, Create_routine_priv, Alter_routine_priv, Create_user_priv, Event_priv, Trigger_priv'

    $ADMIN_PRIV_OR="Select_priv='Y' OR Insert_priv='Y' OR Update_priv='Y' OR Delete_priv='Y' OR Create_priv='Y' OR Drop_priv='Y' OR Reload_priv='Y' OR Shutdown_priv='Y' OR Process_priv='Y' OR File_priv='Y' OR Grant_priv='Y' OR References_priv='Y' OR Index_priv='Y' OR Alter_priv='Y' OR Show_db_priv='Y' OR Super_priv='Y' OR Create_tmp_table_priv='Y' OR Lock_tables_priv='Y' OR Execute_priv='Y' OR Repl_slave_priv='Y' OR Repl_client_priv='Y' OR Create_view_priv='Y' OR Show_view_priv='Y' OR Create_routine_priv='Y' OR Alter_routine_priv='Y' OR Create_user_priv='Y' OR Event_priv='Y' OR Trigger_priv='Y'"
    Section-Header 'D-04. 데이터베이스 관리자 권한을 꼭 필요한 계정 및 그룹에 허용' '계정 별 관리자 권한이 차등 부여 되어 있는 경우 양호'
    $sql = @'
SELECT CONCAT('D-04', ',', IF(COUNT(T.user) > 0, 'X', 'O'), ',,') AS ''
FROM (SELECT User FROM mysql.user WHERE (__ADMIN_PRIV_OR__) GROUP BY User) T
WHERE T.User <> 'root';
'@
    Add-QueryToResult -SkipColumnNames -Sql ($sql.Replace('__ADMIN_PRIV_COLS__', $ADMIN_PRIV_COLS).Replace('__ADMIN_PRIV_OR__', $ADMIN_PRIV_OR))
    $sql = @'
SELECT CASE
WHEN (SELECT COUNT(*) FROM (SELECT User FROM mysql.user WHERE (__ADMIN_PRIV_OR__) AND User <> 'root' GROUP BY User) A) > 0
THEN 'ROOT 외 관리권한이 부여된 계정이 존재해 취약함'
ELSE 'ROOT 외 관리권한이 부여된 계정이 발견되지 않아 양호함'
END AS '';
'@
    Add-QueryToResult -SkipColumnNames -Sql ($sql.Replace('__ADMIN_PRIV_COLS__', $ADMIN_PRIV_COLS).Replace('__ADMIN_PRIV_OR__', $ADMIN_PRIV_OR))
    Write-Log ''; Write-Log '[설정]'
    $sql = @'
SELECT User, __ADMIN_PRIV_COLS__
FROM mysql.user
WHERE (__ADMIN_PRIV_OR__)
GROUP BY User, __ADMIN_PRIV_COLS__;
'@
    Add-QueryToResult -Sql ($sql.Replace('__ADMIN_PRIV_COLS__', $ADMIN_PRIV_COLS).Replace('__ADMIN_PRIV_OR__', $ADMIN_PRIV_OR))
    Write-Log ''

    Section-Header 'D-05. 패스워드 재사용에 대한 제약' 'PASSWORD_REUSE_TIME, PASSWORD_REUSE_MAX 파라미터 설정이 적용된 경우 양호'
    Write-Log 'D-05,N/A,,'; Write-Log 'Oracle 환경에 대한 설정부분으로 해당사항 없음'; Write-Log ''

    $DB_PRIV_COLS='Select_priv, Insert_priv, Update_priv, Delete_priv, Create_priv, Drop_priv, Grant_priv, References_priv, Index_priv, Alter_priv, Create_tmp_table_priv, Lock_tables_priv, Create_view_priv, Show_view_priv, Create_routine_priv, Alter_routine_priv, Execute_priv, Event_priv, Trigger_priv'

    $DB_PRIV_OR="Select_priv='Y' OR Insert_priv='Y' OR Update_priv='Y' OR Delete_priv='Y' OR Create_priv='Y' OR Drop_priv='Y' OR Grant_priv='Y' OR References_priv='Y' OR Index_priv='Y' OR Alter_priv='Y' OR Create_tmp_table_priv='Y' OR Lock_tables_priv='Y' OR Create_view_priv='Y' OR Show_view_priv='Y' OR Create_routine_priv='Y' OR Alter_routine_priv='Y' OR Execute_priv='Y' OR Event_priv='Y' OR Trigger_priv='Y'"
    Section-Header 'D-06. DB 사용자 계정 개별적 부여' '사용자별 계정을 사용하고 있는 경우 양호'
    $sql = @'
SELECT CONCAT('D-06', ',', IF(COUNT(T.db) > 0, 'X', 'O'), ',,') AS ''
FROM (SELECT db, COUNT(user) userCnt FROM mysql.db WHERE (__DB_PRIV_OR__) GROUP BY db) T
WHERE T.userCnt > 1;
'@
    Add-QueryToResult -SkipColumnNames -Sql ($sql.Replace('__DB_PRIV_COLS__', $DB_PRIV_COLS).Replace('__DB_PRIV_OR__', $DB_PRIV_OR))
    $sql = @'
SELECT CASE
WHEN (SELECT COUNT(T.db) FROM (SELECT db, COUNT(user) userCnt FROM mysql.db WHERE (__DB_PRIV_OR__) GROUP BY db) T WHERE T.userCnt > 1) > 0
THEN '2명 이상의 접근 가능 사용자가 할당된 데이터베이스가 발견되어 취약함'
ELSE '2명 이상의 접근 가능 사용자가 할당된 데이터베이스가 발견되지 않아 양호함'
END AS '';
'@
    Add-QueryToResult -SkipColumnNames -Sql ($sql.Replace('__DB_PRIV_COLS__', $DB_PRIV_COLS).Replace('__DB_PRIV_OR__', $DB_PRIV_OR))
    Write-Log ''; Write-Log '[설정]'
    $sql = @'
SELECT db, user
FROM mysql.db
WHERE (__DB_PRIV_OR__);
'@
    Add-QueryToResult -Sql ($sql.Replace('__DB_PRIV_COLS__', $DB_PRIV_COLS).Replace('__DB_PRIV_OR__', $DB_PRIV_OR))
    Write-Log ''

    Section-Header 'D-07. 원격에서 DB 서버로의 접속 제한' '허용된 IP 및 포트에 대한 접근 통제가 되어 있는 경우 양호'
    $sql = @'
SELECT CONCAT('D-07', ',', IF(COUNT(host) > 0, 'X', 'O'), ',,') AS ''
FROM mysql.user
WHERE host = '%' AND user <> '';
'@
    Add-QueryToResult -SkipColumnNames -Sql $sql
    $sql = @'
SELECT CASE
WHEN (SELECT COUNT(DISTINCT user) FROM mysql.user WHERE host = '%' AND user <> '') > 0
THEN 'DB 계정 기준 외부 접근이 허용된 계정이 존재해 취약함'
ELSE 'DB 계정 기준 외부 접근이 허용된 계정이 발견되지 않아 양호함'
END AS '';
'@
    Add-QueryToResult -SkipColumnNames -Sql $sql
    Write-Log ''; Write-Log '[DB 계정 Host 설정]'
    $sql = @'
SELECT DISTINCT host, user
FROM mysql.user
WHERE user <> ''
ORDER BY user, host;
'@
    Add-QueryToResult -Sql $sql
    Write-Log ''

    Section-Header 'D-07-NET. OS 네트워크 리스닝 및 방화벽 노출 확인' 'DB 계정 Host 제한과 별도로 OS/L4/방화벽에서 3306 노출 여부를 확인한 경우 양호'
    $anyListen = Test-TcpAnyListening3306
    $fwAllow = Test-FirewallAllow3306
    if ($anyListen -or $fwAllow) {
        Write-Log 'D-07-NET,C,,'
        Write-Log "[수동진단] DB 계정 Host 제한과 별도로 OS 네트워크 노출 확인 필요. AnyListen3306=$anyListen, FirewallAllowCandidate=$fwAllow"
    } else {
        Write-Log 'D-07-NET,O,,'
        Write-Log "OS 기준 0.0.0.0/[::] 리스닝 또는 명시적 3306 허용 방화벽 후보가 확인되지 않음. AnyListen3306=$anyListen, FirewallAllowCandidate=$fwAllow"
    }
    Write-Log '[참고] 상세 증적은 하단 Windows / MariaDB RAW의 netstat 및 Firewall Rules filtered 참조'
    Write-Log ''

    Section-Header 'D-08. DBA이외의 인가되지 않은 사용자 시스템 테이블 접근 제한 설정' 'DBA만 접근 가능한 테이블에 일반 사용자 접근이 불가능 할 경우 양호'
    $sql = @'
SELECT CONCAT('D-08', ',', IF(COUNT(T.cnt) > 0, 'X', 'O'), ',,') AS ''
FROM (SELECT db, COUNT(*) cnt FROM mysql.db WHERE (__DB_PRIV_OR__) GROUP BY db) T
WHERE T.db = 'mysql';
'@
    Add-QueryToResult -SkipColumnNames -Sql ($sql.Replace('__DB_PRIV_COLS__', $DB_PRIV_COLS).Replace('__DB_PRIV_OR__', $DB_PRIV_OR))
    $sql = @'
SELECT CASE
WHEN (SELECT COUNT(user) FROM mysql.db WHERE (__DB_PRIV_OR__) AND db = 'mysql') > 0
THEN 'mysql 데이터베이스의 접근 또는 관리권한이 부여된 계정이 존재해 취약함'
ELSE 'mysql 데이터베이스의 접근 또는 관리권한이 부여된 계정이 발견되지 않아 양호함'
END AS '';
'@
    Add-QueryToResult -SkipColumnNames -Sql ($sql.Replace('__DB_PRIV_COLS__', $DB_PRIV_COLS).Replace('__DB_PRIV_OR__', $DB_PRIV_OR))
    Write-Log ''; Write-Log '[설정]'
    $sql = @'
SELECT *
FROM mysql.db
WHERE (__DB_PRIV_OR__) AND db = 'mysql';
'@
    Add-QueryToResult -Sql ($sql.Replace('__DB_PRIV_COLS__', $DB_PRIV_COLS).Replace('__DB_PRIV_OR__', $DB_PRIV_OR))
    Write-Log ''

    foreach ($item in @(
        @('D-09. 오라클 데이터베이스의 경우 리스너 패스워드 설정','Listener의 패스워드가 설정되어 있는 경우 양호','D-09,N/A,,','Oracle 환경에 대한 설정부분으로 해당사항 없음'),
        @('D-10. 불필요한 ODBC/OLE-DB 데이터 소스와 드라이브 제거','불필요한 ODBC/OLE-DB가 설치되지 않은 경우 양호','D-10,N/A,,','Windows ODBC/OLE-DB 항목은 별도 DSN 점검이 필요함'),
        @('D-11. 일정 횟수의 로그인 실패 시 잠금 정책 설정','로그인 시도 횟수를 제한하는 값을 설정한 경우 양호','D-11,N/A,,','MySQL/MariaDB 기본 기능 또는 플러그인/버전에 따라 수동 확인 필요')
    )) { Section-Header $item[0] $item[1]; Write-Log $item[2]; Write-Log $item[3]; Write-Log '' }

    Section-Header 'D-12. 데이터베이스의 주요 파일 보호 등을 위해 DB 계정의 umask를 022 이상으로 설정' 'Windows에서는 umask가 아닌 NTFS ACL 및 서비스 실행계정 권한으로 확인'
    Write-Log 'D-12,C,,'; Write-Log '[수동진단] Windows 환경은 umask 대신 서비스 계정, 데이터/설정파일 NTFS ACL 확인 필요'; Write-Log ''

    Section-Header 'D-13. 데이터베이스의 주요 설정파일, 패스워드 파일 등 주요 파일들의 접근 권한 설정' '주요 설정 파일 및 디렉터리의 NTFS ACL이 최소권한인 경우 양호'
    Write-Log 'D-13,C,,'; Write-Log '[수동진단] 아래 Config File RAW의 Owner/ACL 확인 필요'; Write-Log ''

    foreach ($item in @(
        @('D-14. 관리자 이외의 사용자가 오라클 리스너의 접속을 통해 리스너 로그 및 trace 파일에 대한 변경 권한 제한','주요 설정 파일 및 로그 파일에 대한 퍼미션을 관리자로 설정한 경우 양호','D-14,N/A,,','Oracle 환경에 대한 설정부분으로 해당사항 없음'),
        @('D-15. 응용프로그램 또는 DBA 계정의 Role이 Public으로 설정되지 않도록 조정','DBA 계정의 Role이 Public으로 설정되어 있지 않은 경우 양호','D-15,N/A,,','Oracle 및 MSSQL 환경에 대한 설정부분으로 해당사항 없음'),
        @('D-16. OS_ROLES, REMOTE_OS_AUTHENTICATION, REMOTE_OS_ROLES를 FALSE로 설정','OS_ROLES, REMOTE_OS_AUTHENTICATION, REMOTE_OS_ROLES설정이 FALSE로 되어있는 경우 양호','D-16,N/A,,','Oracle 환경에 대한 설정부분으로 해당사항 없음'),
        @('D-17. 패스워드 확인함수가 설정되어 적용되는가?','패스워드 검증 함수로 검증이 진행되는 경우 양호','D-17,N/A,,','Oracle 환경에 대한 설정부분으로 해당사항 없음'),
        @('D-18. 인가되지 않은 Object Owner가 존재하지 않는가?','Object Owner 의 권한이 SYS, SYSTEM, 관리자 계정 등으로 제한된 경우 양호','D-18,N/A,,','Oracle 환경에 대한 설정부분으로 해당사항 없음'),
        @('D-19. grant option이 role에 의해 부여되도록 설정','WITH_GRANT_OPTION이 ROLE에 의하여 설정되어있는 경우 양호','D-19,N/A,,','Oracle 환경에 대한 설정부분으로 해당사항 없음'),
        @('D-20. 데이터베이스의 자원 제한 기능을 TRUE로 설정','RESOURCE_LIMIT 설정이 TRUE로 되어있는 경우 양호','D-20,N/A,,','Oracle 환경에 대한 설정부분으로 해당사항 없음')
    )) { Section-Header $item[0] $item[1]; Write-Log $item[2]; Write-Log $item[3]; Write-Log '' }

    Section-Header 'D-21. 데이터베이스에 대해 최신 보안 패치와 밴더 권고사항을 모두 적용' '버전 별 최신 패치를 적용한 경우 양호'
    $DOT1VERSION = Invoke-QueryText "SELECT SUBSTRING_INDEX(VERSION(), '.', 2);"
    $DB_FLAVOR = Get-DbFlavorText -VersionText $DBVER
    $LATESTVER = ''; $DB23_EXPIRE = 0; $VERSION_NOTE = ''
    if ($DB_FLAVOR -eq 'MariaDB' -and $DOT1VERSION -eq '10.4') {
        $LATESTVER = $LAT_MARIA_104
        $cmpLatest = Compare-VersionText -Left $DBVER -Right $LATESTVER
        if ($null -eq $cmpLatest) {
            Write-Log 'D-21,C,,'
            Write-Log "MariaDB 10.4 계열로 보이나 버전 비교 실패. 상세 버전=$DBVER, 기준=$LATESTVER"
        } elseif ($cmpLatest -lt 0) {
            Write-Log 'D-21,X,,'
            Write-Log "MariaDB 10.4 최종 패치 기준($LATESTVER)보다 낮아 취약 가능성이 높음. 현재=$DBVER"
        } else {
            Write-Log 'D-21,C,,'
            Write-Log "MariaDB 10.4 최종 패치 기준($LATESTVER) 이상이나, 10.4 계열은 Community maintenance 종료 이슈가 있어 업그레이드/벤더 지원 여부 수동 확인 필요. 현재=$DBVER"
        }
    } else {
        switch ($DOT1VERSION) { '5.5' { $LATESTVER=$LAT_55 } '5.6' { $LATESTVER=$LAT_56 } '5.7' { $LATESTVER=$LAT_57 } '8.0' { $LATESTVER=$LAT_80 } default { $DB23_EXPIRE=1 } }
        if ($DB23_EXPIRE -eq 0) {
            $ISLATEST = Invoke-QueryText "SELECT SUBSTRING_INDEX(VERSION(), '-', 1) >= '$LATESTVER';"; if (-not $ISLATEST) { $ISLATEST='0' }
            if ($ISLATEST -eq '1') { Write-Log 'D-21,O,,'; Write-Log "데이터베이스가 '$LATESTVER'과 같거나 높아 양호함" } else { Write-Log 'D-21,X,,'; Write-Log "데이터베이스가 '$LATESTVER'보다 낮아 취약함" }
        } else { Write-Log 'D-21,C,,'; Write-Log "현재 버전($DOT1VERSION, Flavor=$DB_FLAVOR)에 대한 최신 버전 기준이 스크립트에 정의되어 있지 않아 수동 확인 필요" }
    }
    Write-Log ''

    Section-Header 'D-22. 데이터베이스의 접근, 변경, 삭제 등의 감사기록이 기관의 감사기록 정책에 적합하도록 설정' 'DBMS의 감사 로그 저장 정책이 수립되어 있으며, 정책이 적용되어 있는 경우 양호'
    Write-Log 'D-22,N/A,,'; Write-Log 'Oracle 및 MSSQL 환경에 대한 설정부분으로 해당사항 없음'; Write-Log ''

    Section-Header 'D-23. 보안에 취약하지 않은 버전의 데이터베이스를 사용하고 있는가?' '보안 패치가 지원되는 버전을 사용하는 경우 양호'
    if ($DB_FLAVOR -eq 'MariaDB' -and $DOT1VERSION -eq '10.4') {
        Write-Log 'D-23,X,,'
        Write-Log 'MariaDB 10.4 계열은 Community maintenance 종료 계열로 보안 패치 지원 여부 및 상위 LTS 업그레이드 검토 필요'
    } elseif ($DB23_EXPIRE -eq 0) {
        Write-Log 'D-23,O,,'; Write-Log '현재 사용하고 있는 데이터베이스는 스크립트 기준상 업데이트 지원 대상 버전으로 확인됨'
    } else {
        Write-Log 'D-23,C,,'; Write-Log '현재 사용하고 있는 데이터베이스는 스크립트 기준상 지원 여부를 자동 확정하지 못해 수동 확인 필요'
    }
    Write-Log ''; Write-Log '[설정]'; Write-Log "DB Flavor : $DB_FLAVOR"; Write-Log "데이터베이스 버전 : $DOT1VERSION"; Write-Log "상세 버전 : $DBVER"; Write-Log "MariaDB 10.4 final patch baseline : $LAT_MARIA_104"; Write-Log ''

    Section-Header 'D-24. Audit Table은 데이터베이스 관리자 계정에 속해 있도록 설정' 'Audit Table 접근 권한이 관리자 계정으로 설정한 경우 양호'
    Write-Log 'D-24,N/A,,'; Write-Log 'Oracle 환경에 대한 설정부분으로 해당사항 없음'; Write-Log ''

    Write-Log ''; Write-Log '------------------------MariaDB/MySQL Process Check---------------------------'
    Write-Log "[명령어] Get-CimInstance Win32_Process | Where Name/CommandLine contains maria/mysql/mysqld"
    Collect-WindowsRaw
    Collect-ConfigFilesRaw

    Write-Log ''; Write-Log '------------------------MariaDB/MySQL Runtime RAW---------------------------'
    Write-Log '[SELECT VERSION()]'
    Add-QueryToResult -Sql "SELECT VERSION() AS version, @@version_comment AS version_comment, @@hostname AS db_hostname, @@port AS db_port;" -Label 'Runtime RAW - SELECT VERSION'
    Write-Log ''; Write-Log '[SHOW VARIABLES - selected]'
    Add-QueryToResult -Sql "SHOW VARIABLES WHERE Variable_name IN ('version','version_comment','datadir','basedir','port','socket','bind_address','skip_networking','local_infile','secure_file_priv','log_error','general_log','general_log_file','slow_query_log','slow_query_log_file','log_bin','server_id','plugin_dir','ssl_ca','ssl_cert','ssl_key','require_secure_transport','default_authentication_plugin','old_passwords','password_reuse_interval','password_reuse_history');" -Label 'Runtime RAW - SHOW VARIABLES selected'
    Write-Log ''; Write-Log '[SHOW GRANTS - current user]'
    Add-QueryToResult -Sql "SHOW GRANTS FOR CURRENT_USER();" -Label 'Runtime RAW - SHOW GRANTS FOR CURRENT_USER'

    Write-SqlRawDataToResult

    if ((Test-Path $RawLog) -and ((Get-Item $RawLog).Length -eq 0)) { Remove-Item -LiteralPath $RawLog -Force -ErrorAction SilentlyContinue }

    Write-Host ''
    Write-Host "Please Return your $Result"
}
finally {
    if ($script:TempDefaults -and (Test-Path $script:TempDefaults)) { Remove-Item -LiteralPath $script:TempDefaults -Force -ErrorAction SilentlyContinue }
}
