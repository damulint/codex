MariaDB/MySQL Windows Audit v1.10
================================

변경 요약
- MariaDB 10.11에서 D-04 권한 컬럼 비교 시 발생하는 ERROR 1271 (Illegal mix of collations for operation 'in') 문제 수정
- 기존 WHERE 'Y' IN (Select_priv, Insert_priv, ... ) 패턴을 모두 컬럼별 OR 비교 방식으로 변경
- D-04, D-06, D-08의 mysql.user/mysql.db 권한 컬럼 조건에 동일한 보정 적용
- v1.9의 SQL QUERY RAW DATA 및 계정/인증 해시 RAW 수집 기능 유지
- v1.8의 MariaDB 10.4 버전 판정, D-07 계정/네트워크 분리, 활성 설정파일 분리 기능 유지

실행 예시
Run_mariaDB_windows_audit.bat -Client "C:\Program Files\MariaDB 10.4\bin\mariadb.exe" -HostName 127.0.0.1 -Port 3306 -User root -Password "패스워드" -NoPrompt

MariaDB 10.11 호환성 보정 내용
기존:
  WHERE 'Y' IN (Select_priv, Insert_priv, ...)

변경:
  WHERE (Select_priv='Y' OR Insert_priv='Y' OR ...)

이 방식은 권한 컬럼 간 collation이 다르게 잡힌 환경에서도 'IN' 연산으로 인한 collation 충돌을 피합니다.
